# ReactQuery

- API 백엔드 서버와 통신 전용(비동기)
- Web Application 전체 상태 관리
- 레퍼런스 [https://tanstack.com/query/latest/docs/framework/react/overview]

## 1. 버전 선택시 주의 사항

- V5 : 리액트 18 버전 이상
- V4 : 리액트 16.8 버전 이상
- V3 : 리액트 16.8 버전 이상

## 2. V5 설치

`npm i @tanstack/react-query`

## 3. 개발자 도구

`npm i @tanstack/react-query-devtools`

## 4. ReactQuery 셋팅

- 웹앱 전체 상태관리 / API 백엔드 연동
- index.js 또는 App.js

```js
import { RouterProvider } from "react-router-dom";
import router from "./router/root";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
// ReactQuey 셋팅
// 왜 App.js 에서 셋팅을 할까? (웹서비스 전체에 상태관리)
const queryClient = new QueryClient();
const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />;
    </QueryClientProvider>
  );
};

export default App;
```

## 5. ReactQuery Devtools 셋팅

- src/App.js

```js
import { RouterProvider } from "react-router-dom";
import router from "./router/root";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
// ReactQuey 셋팅
// 왜 App.js 에서 셋팅을 할까? (웹서비스 전체에 상태관리)
const queryClient = new QueryClient();
const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
      {/* 리액트쿼리 개발자도구 */}
      <ReactQueryDevtools initialIsOpen={true} />
    </QueryClientProvider>
  );
};

export default App;
```

## 6. ReactQuery 데이터 연동

- useQuery()
  : API 백엔드 서버에서 데이터를 읽을 때

- useMutaion()
  : API 백엔드 서버에서 데이터를 변경할떄

## 7. useQuery 활용하여 데이터 읽기

- API 참조하기(V5)
  : https://tanstack.com/query/latest/docs/framework/react/reference/useQuery

- API 기본 구조 분석

```js
const {
  리턴되는 값,
  리턴되는 값,
  리턴되는 값,
} = useQuery(
  {
    매개변수이름: 매개변수값,
    매개변수이름: 매개변수값,
    매개변수이름: 매개변수값,
  },
  queryClient,
)
```

- src/components/product/ProductReadComponent.js
