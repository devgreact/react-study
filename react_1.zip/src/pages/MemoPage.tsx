const MemoPage = () => {
  return <div>MemoPage</div>;
};

export default MemoPage;
