import React from "react";
import ModifyComponent from "../../components/member/ModifyComponent";

const ModifyPage = () => {
  return (
    <div>
      <h1>정보수정</h1>
      <ModifyComponent />
    </div>
  );
};

export default ModifyPage;
