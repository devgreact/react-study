import React from "react";
import LoginComponents from "../../components/member/LoginComponents";

const LoginPage = () => {
  return (
    <div>
      <h1>LoginPage</h1>
      <LoginComponents />
    </div>
  );
};

export default LoginPage;
