// action.type 은 별도의 파일로 관리
// 절대로 중복되면 안됩니다.
export const COUNT_UP = "count/up";
export const COUNT_DOWN = "count/down";
export const COUNT_INIT = "count/init";
