import React from "react";
import ProductAddComponent from "../../components/product/ProductAddComponent";

const ProductAddPage = () => {
  return (
    <div>
      <h1>ProductAddPage</h1>
      <ProductAddComponent />
    </div>
  );
};

export default ProductAddPage;
