import React from "react";
import AddComponent from "../../components/todo/AddComponent";
const AddPage = () => {
  return (
    <div>
      <h1>할일 등록</h1>
      <AddComponent />
    </div>
  );
};

export default AddPage;
