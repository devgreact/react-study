import React from "react";
import ListComponent from "../../components/todo/ListComponent";

const ListPage = () => {
  return (
    <div>
      <h1>목록페이지</h1>
      <ListComponent />
    </div>
  );
};

export default ListPage;
